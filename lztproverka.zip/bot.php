<?
#Добавляем в бота коннект к бд, и связываем мини библиотеку с файлом бота
include "connect.php";
include "prm.php";


#Реагируем на старт бота
if ($text == '/start')
{
    $check_user = mysqli_query($connect, "SELECT * FROM `proverka` WHERE `chat_id` = '$chat_id'");
    if (mysqli_num_rows($check_user) == 0)
    {
        mysqli_query($connect, "INSERT INTO `proverka` (`chat_id`) VALUES ('$chat_id')");
    }

    $menu[] = ['text' => "Библиотека", 'callback_data' => "/mylib"];
    $menu = array_chunk($menu, 1);
    $menu = ['inline_keyboard' => $menu];

    sendTelegram('sendMessage', array(
        'chat_id' => $chat_id,
        'text' => "<i>Привет @$name!</i>

<b>Я - бот приложение который представляет собой базу управления книгами в библиотеке.</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($menu)
    ));
    mysqli_query($connect, "UPDATE `proverka` SET `books` = '0' WHERE `chat_id` = '$chat_id' ");
}


#Обрабатываем кнопку "Библиотека"
if ($cbd == '/mylib')
{
    mysqli_query($connect, "UPDATE `proverka` SET `books` = '0' WHERE `chat_id` = '$chat_id_in' ");
    $menu[] = ['text' => "📚 Список книг", 'callback_data' => "/allbooks"];
    $menu[] = ['text' => "🔎 Поиск книги", 'callback_data' => "/searchbook"];
    $menu[] = ['text' => "➕ Добавить книгу", 'callback_data' => "/addbook"];
    $menu = array_chunk($menu, 2);
    $menu = ['inline_keyboard' => $menu];

    sendTelegram('sendMessage', array(
        'chat_id' => $chat_id_in,
        'text' => "<i>👋🏻 Привет, @$namein!</i>

<b>Выбери действие:</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($menu)
    ));
}


#Обрабатываем кнопку "Добавить книгу"
if ($cbd == '/addbook')
{
    $menu[] = ['text' => "🔙 В меню", 'callback_data' => "/mylib"];
    $menu = array_chunk($menu, 2);
    $menu = ['inline_keyboard' => $menu];
    mysqli_query($connect, "UPDATE `proverka` SET `books` = '2' WHERE `chat_id` = '$chat_id_in' ");
    sendTelegram('editMessageText', array(
        'chat_id' => $chat_id_in,
        'message_id' => $mess_id_in,
        'text' => "<b>➕ Добавление книги:</b>

<b>Напишите название книги:</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($menu)
    ));
    return false;
}

$request = mysqli_query($connect, "SELECT * FROM `proverka` WHERE `chat_id` = '$chat_id' LIMIT 1 ");
while ($books = mysqli_fetch_assoc($request))
{
    $act = $books['books'];
}
if ($act == 2)
{
    mysqli_query($connect, "INSERT INTO `books` (`book`,`author`,`description`,`genre`) VALUES ('$text','NULL','NULL','NULL')");
    sendTelegram('sendMessage', array(
        'chat_id' => $chat_id,
        'text' => "📝",
        'parse_mode' => 'html'
    ));
    sendTelegram('sendMessage', array(
        'chat_id' => $chat_id,
        'text' => "<b>➕ Добавление книги:</b>

<b>Напишите Автора книги:</b>",
        'parse_mode' => 'html'
    ));
    mysqli_query($connect, "UPDATE `proverka` SET `books` = '3' WHERE `chat_id` = '$chat_id' ");
    return false;
}
if ($act == 3)
{
    sendTelegram('sendMessage', array(
        'chat_id' => $chat_id,
        'text' => "📝",
        'parse_mode' => 'html'
    ));
    sendTelegram('sendMessage', array(
        'chat_id' => $chat_id,
        'text' => "<b>➕ Добавление книги:</b>

<b>Напишите описание книги:</b>",
        'parse_mode' => 'html'
    ));
    mysqli_query($connect, "UPDATE `books` SET `author` = '$text' WHERE `author` = 'NULL' ");
    mysqli_query($connect, "UPDATE `proverka` SET `books` = '4' WHERE `chat_id` = '$chat_id' ");
    return false;
}
if ($act == 4)
{
    sendTelegram('sendMessage', array(
        'chat_id' => $chat_id,
        'text' => "📝",
        'parse_mode' => 'html'
    ));
    sendTelegram('sendMessage', array(
        'chat_id' => $chat_id,
        'text' => "<b>➕ Добавление книги:</b>

<b>Напишите жанр книги:</b>",
        'parse_mode' => 'html'
    ));
    mysqli_query($connect, "UPDATE `books` SET `description` = '$text' WHERE `description` = 'NULL' ");
    mysqli_query($connect, "UPDATE `proverka` SET `books` = '5' WHERE `chat_id` = '$chat_id' ");
    return false;
}
if ($act == 5)
{
    $menu[] = ['text' => "🔙 В меню", 'callback_data' => "/mylib"];
    $menu = array_chunk($menu, 2);
    $menu = ['inline_keyboard' => $menu];
    sendTelegram('sendMessage', array(
        'chat_id' => $chat_id,
        'text' => "✅ Книга успешно добавлена!",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($menu)
    ));
    mysqli_query($connect, "UPDATE `books` SET `genre` = '$text' WHERE `genre` = 'NULL' ");
    mysqli_query($connect, "UPDATE `proverka` SET `books` = '0' WHERE `chat_id` = '$chat_id' ");
    return false;
}


#Обрабатываем кнопку "Поиск книги"
if ($cbd == '/searchbook')
{
    $menu[] = ['text' => "🔙 В меню", 'callback_data' => "/mylib"];
    $menu = array_chunk($menu, 2);
    $menu = ['inline_keyboard' => $menu];
    mysqli_query($connect, "UPDATE `proverka` SET `books` = '1' WHERE `chat_id` = '$chat_id_in' ");
    sendTelegram('editMessageText', array(
        'chat_id' => $chat_id_in,
        'message_id' => $mess_id_in,
        'text' => "<b>🔎 Поиск книги:</b>

<b>Введи ключевые слова автора книги, или название книги для ее поиска.</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($menu)
    ));
    return false;
}

$request = mysqli_query($connect, "SELECT * FROM `proverka` WHERE `chat_id` = '$chat_id' LIMIT 1 ");
while ($books = mysqli_fetch_assoc($request))
{
    $act = $books['books'];
    if ($act == 1)
    {
        sendTelegram('sendMessage', array(
            'chat_id' => $chat_id,
            'text' => "🔎",
            'parse_mode' => 'html'
        ));
        $find = mysqli_real_escape_string($connect, $text); #Зеркалим запрос от жестких хакеров
        $result = mysqli_query($connect, "SELECT * FROM `books` WHERE `book` LIKE '%$find%' OR `author` LIKE '%$find%'");
        $rows = mysqli_num_rows($result);
        if ($rows > 0)
        {
            while ($books = mysqli_fetch_assoc($result))
            {
                $book = $books['book'];
                $author = $books['author'];
                $id = $books['id'];
                $bookmenu[] = ['text' => "$book | $author", 'callback_data' => "/showbook_$id"];
            }

            $bookmenu = array_chunk($bookmenu, 2);
            $bookmenu = ['inline_keyboard' => $bookmenu];
            sendTelegram('sendMessage', array(
                'chat_id' => $chat_id,
                'text' => "<b>✅ Найдено</b> <code>$rows</code> <b>книг:</b>
<b>Выбери книгу для просмотра подробной информации:</b>",
                'parse_mode' => 'html',
                'reply_markup' => json_encode($bookmenu)
            ));
        }
        if ($rows == '0')
        {
            sendTelegram('sendMessage', array(
                'chat_id' => $chat_id,
                'text' => "<b>❌ К сожалению книги по вашему запросу не найдены :/</b>",
                'parse_mode' => 'html'
            ));
            mysqli_query($connect, "UPDATE `proverka` SET `books` = '0' WHERE `chat_id` = '$chat_id' ");
        }
    }
}


#Обрабатываем кнопку "Общий список книг"
if ($cbd == '/allbooks')
{
    $menu[] = ['text' => "Поиск книги по жанру", 'callback_data' => "/showgenrebooks"];
    $menu[] = ['text' => "Отобразить все книги", 'callback_data' => "/showallbooks"];
    $menu = array_chunk($menu, 1);
    $menu = ['inline_keyboard' => $menu];

    sendTelegram('editMessageText', array(
        'chat_id' => $chat_id_in,
        'message_id' => $mess_id_in,
        'text' => "<b>📋 Общий список книг:</b>

<b>Выбери метод отображения списка книг</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($menu)
    ));
}


#Обрабатываем кнопку "Отобразить все книги"
if ($cbd == '/showallbooks')
{
    $request = mysqli_query($connect, "SELECT * FROM `books`");
    $rows = mysqli_num_rows($request);
    while ($books = mysqli_fetch_assoc($request))
    {
        $book = $books['book'];
        $author = $books['author'];
        $id = $books['id'];
        $bookmenu[] = ['text' => "$book | $author", 'callback_data' => "/showbook_$id"];
    }
    $bookmenu = array_chunk($bookmenu, 2);
    $bookmenu = ['inline_keyboard' => $bookmenu];

    sendTelegram('editMessageText', array(
        'chat_id' => $chat_id_in,
        'message_id' => $mess_id_in,
        'text' => "<b>📋 Общий список книг:</b>
<b>Количество книг в нашей библиотеке:</b> <code>$rows</code>

<b>Выбери книгу для просмотра подробной информации:</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($bookmenu)
    ));
}


#Обрабатываем кнопку "Поиск книги по жанру"
if ($cbd == '/showgenrebooks')
{
    $request = mysqli_query($connect, "SELECT * FROM `books`");
    $rows = mysqli_num_rows($request);
    while ($books = mysqli_fetch_assoc($request))
    {
        $genre = $books['genre'];
        $id = $books['id'];
        $bookmenu[] = ['text' => "$genre", 'callback_data' => "/showbookgenre_$genre"];
    }
    $bookmenu = array_chunk($bookmenu, 2);
    $bookmenu = ['inline_keyboard' => $bookmenu];

    sendTelegram('editMessageText', array(
        'chat_id' => $chat_id_in,
        'message_id' => $mess_id_in,
        'text' => "<b>📋 Общий список книг:</b>

<b>Выбери жанр:</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($bookmenu)
    ));
}


#Обрабатываем кнопку "Выбора жанра"
if (in_array(mb_strtolower($messagesin[0]) , ['trimcmd', '/showbookgenre']))
{
    $trimcmd = substr_replace($cbd2, null, 0, 15);
    $request = mysqli_query($connect, "SELECT * FROM `books` WHERE `genre` = '$trimcmd' ");
    $rows = mysqli_num_rows($request);
    while ($books = mysqli_fetch_assoc($request))
    {
        $book = $books['book'];
        $author = $books['author'];
        $id = $books['id'];
        $bookmenu[] = ['text' => "$book | $author", 'callback_data' => "/showbook_$id"];
    }
    $bookmenu = array_chunk($bookmenu, 2);
    $bookmenu = ['inline_keyboard' => $bookmenu];

    sendTelegram('editMessageText', array(
        'chat_id' => $chat_id_in,
        'message_id' => $mess_id_in,
        'text' => "<b>📋 Общий список книг по выбранному жанру $trimcmd:</b>
<b>Количество книг в нашей библиотеке:</b> <code>$rows</code>

<b>Выбери книгу для просмотра подробной информации:</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($bookmenu)
    ));

}


#Обрабатываем кнопку "Удалить книгу"
if (in_array(mb_strtolower($messagesin[0]) , ['trimcmd', '/deletebook']))
{

    $trimcmd = substr_replace($cbd2, null, 0, 12);

    $menu[] = ['text' => "🔙 В меню", 'callback_data' => "/mylib"];
    $menu = array_chunk($menu, 2);
    $menu = ['inline_keyboard' => $menu];
    sendTelegram('editMessageText', array(
        'chat_id' => $chat_id_in,
        'message_id' => $mess_id_in,
        'text' => "✅ Книга успешно удалена!",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($menu)
    ));
    mysqli_query($connect3, "DELETE FROM `books` where `id` = '$trimcmd'");
}


#Обрабатываем кнопку "Просмотр информации по книге"
if (in_array(mb_strtolower($messagesin[0]) , ['trimcmd', '/showbook']))
{
    $trimcmd = substr_replace($cbd2, null, 0, 10);
    $request = mysqli_query($connect, "SELECT * FROM `books` WHERE `id` = '$trimcmd' ");
    $rows = mysqli_num_rows($request);
    while ($books = mysqli_fetch_assoc($request))
    {
        $book = $books['book'];
        $author = $books['author'];
        $id = $books['id'];
        $desc = $books['description'];
    }
    $bookmenu[] = ['text' => "✖️ Удалить книгу", 'callback_data' => "/deletebook_$id"];
    $bookmenu = array_chunk($bookmenu, 2);
    $bookmenu = ['inline_keyboard' => $bookmenu];
    sendTelegram('editMessageText', array(
        'chat_id' => $chat_id_in,
        'message_id' => $mess_id_in,
        'text' => "<b>📖 Выбранная книга:</b> $book
<b>©️ Автор книги:</b> $author
<b>ℹ️ Описание книги:</b> $desc",
        'parse_mode' => 'html',
        'reply_markup' => json_encode($bookmenu)
    ));

}

?>
