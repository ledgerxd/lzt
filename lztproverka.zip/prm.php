<?php
date_default_timezone_set('Europe/Moscow');


#Config:

define('TOKEN', '6702099625:AAFpwp5Nm8tD4iVUNLufkBYe-6Kr8oiABX8');


//Переменные
$vremya = date('d.m.Y, H:i'); //Фулл дата
$dmy = date('d.m.Y'); //Фулл дата
$vremya2 = date('H:i'); //Часы минуты
$today = date("Y-m-d H:i:s");
$data = file_get_contents('php://input');
$data = json_decode($data, true);
$ent = $data['message']['entities'];
$stickerID = $data['message']['sticker']['file_id'];
$stickerID2 = $data['message']['sticker']['thumb']['file_id'];
$stickerID3 = $data['message']['sticker']['set_name'];
$name = $data["message"]["from"]["username"];
$namein = $data["callback_query"]["from"]["username"];
$cidin = $data["callback_query"]["from"]["id"];
$nameorig = $data["message"]['from']["chat"]["username"];
$chat_id = $data["message"]["chat"]["id"];
$chat_id2 = $data["message"]["from"]['sender_chat']["id"];
$newmembercid = $data["message"]["new_chat_member"]["id"];
$leftmembercid = $data["message"]["left_chat_member"]["id"];
$newmembername = $data["message"]['new_chat_member']["username"];
$firstnmb = $data["message"]['new_chat_member']["first_name"];
$chat_idgrp = $data["message"]["from"]["id"];
$text = $data['message']['text'];
$text2 = $data['message']['channel_post']['text'];
$mess_id = $data["message"]["message_id"];
function sendTelegram($method, $response)
{
    $ch = curl_init('https://api.telegram.org/bot' . TOKEN . '/' . $method);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $response);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    $res = curl_exec($ch);
    curl_close($ch);
    return $res;
}
$message = $data["message"]['text'];
$messages = explode(" ", $message);
$rr = rand(6, 7);
$callback_query = $data['callback_query'];
$cbd = $callback_query['data'];
$cbd2 = $callback_query['data'];
$cbd3 = $callback_query['id'];
$messagesin = explode("_", $cbd2);
$chat_id_in = $callback_query['message']['chat']['id'];
$mess_id_in = $callback_query['message']['message_id'];
$inline_keyboard = [[$inline_button2]];
$replyMarkup = json_encode($keyboard);
$replyMarkup = json_encode($keyboardmain);
?>
