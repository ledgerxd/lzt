<?  
    
    $connect = mysqli_connect('localhost', 'Username', 'Password', 'DataBaseName');

        if (!$connect) {

        die('Error connect to DataBase');

    }
    
?>